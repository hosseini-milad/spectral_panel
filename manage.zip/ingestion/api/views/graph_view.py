from rest_framework.views import APIView
from rest_framework.response import Response

from ..serializers.graph_serializer import GraphSerializer
from ...pipelines.graph_pipeline import run_graph_pipeline


class GraphView(APIView):

    def post(self, request):

        serializer = GraphSerializer(data=request.data)

        if not serializer.is_valid():
            return Response(serializer.errors, status=400)

        source_file = serializer.validated_data["source_file"]

        stats = run_graph_pipeline(source_file)

        return Response({
            "message": "graph created",
            "stats": stats
        })
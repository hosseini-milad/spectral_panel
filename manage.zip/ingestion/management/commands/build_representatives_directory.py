from collections import Counter

from django.core.management.base import BaseCommand, CommandError

from ingestion.models.dataset_metadata import DatasetMetadata
from ingestion.models.graph_metadata import GraphMetadata
from ingestion.models.graph_representative import GraphRepresentative
from ingestion.models.normalized_data import NormalizedSecurityData
from ingestion.models.sampled_data import SampledSecurityData
from ingestion.pipelines.graph_pipeline import run_graph_pipeline
from ingestion.pipelines.pooling_pipeline import run_pooling
from ingestion.pipelines.sampling_pipeline import run_sampling


class Command(BaseCommand):
    help = (
        "Build stratified samples, similarity graphs, and eigenvector-aware "
        "representatives for each ingested source without creating images."
    )
    requires_system_checks = []

    def add_arguments(self, parser):
        parser.add_argument("--sample-ratio", type=float, default=0.1)
        parser.add_argument("--representative-ratio", type=float, default=0.15)

    def handle(self, *args, **options):
        sample_ratio = options["sample_ratio"]
        representative_ratio = options["representative_ratio"]
        if not 0 < sample_ratio <= 1:
            raise CommandError("sample-ratio must be in (0, 1].")
        if not 0 < representative_ratio < 1:
            raise CommandError("representative-ratio must be in (0, 1).")

        sources = sorted(
            item.source_file
            for item in DatasetMetadata.objects.only("source_file")
            if item.source_file
        )
        if not sources:
            raise CommandError("No ingested sources found in dataset metadata.")

        for source_file in sources:
            normalized_count = NormalizedSecurityData.objects(
                source_file=source_file
            ).count()
            if not normalized_count:
                raise CommandError(
                    f"No normalized records found for {source_file}; "
                    "normalize it before graph construction."
                )
            invalid_labels = NormalizedSecurityData.objects(
                source_file=source_file, label__nin=[0, 1]
            ).count()
            if invalid_labels:
                raise CommandError(
                    f"{source_file} contains {invalid_labels} invalid binary labels."
                )

        for source_file in sources:
            normalized_count = NormalizedSecurityData.objects(
                source_file=source_file
            ).count()
            try:
                sampled_count = run_sampling(source_file, sample_ratio)
                graph_stats = run_graph_pipeline(
                    source_file,
                    create_visualization=False,
                )
                if graph_stats is None:
                    raise ValueError("Graph construction returned no result.")

                graph = GraphMetadata.objects(source_file=source_file).first()
                sampled_docs = list(
                    SampledSecurityData.objects(source_file=source_file)
                    .order_by("id")
                    .as_pymongo()
                )
                representatives = run_pooling(
                    source_file=source_file,
                    edges=graph.edges,
                    features=graph.features,
                    docs=sampled_docs,
                    ratio=representative_ratio,
                    create_visualization=False,
                )
            except Exception as exc:
                raise CommandError(
                    f"Representative pipeline failed for {source_file}: {exc}"
                ) from exc

            sampled_labels = Counter(item.get("label") for item in sampled_docs)
            representative_labels = Counter(
                item["label"] for item in representatives
            )
            stored_count = GraphRepresentative.objects(
                source_file=source_file
            ).count()
            self.stdout.write(
                f"{source_file}: normalized={normalized_count}, sampled={sampled_count}, "
                f"sampled_labels={dict(sampled_labels)}, "
                f"graph_nodes={graph_stats['num_nodes']}, "
                f"graph_edges={graph_stats['num_edges']}, "
                f"representatives={stored_count}, "
                f"representative_labels={dict(representative_labels)}"
            )

        self.stdout.write(
            self.style.SUCCESS(
                f"Built samples, similarity graphs, and representatives for "
                f"{len(sources)} sources. No images or spectral/temporal outputs created."
            )
        )

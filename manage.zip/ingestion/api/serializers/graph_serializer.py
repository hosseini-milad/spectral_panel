from rest_framework import serializers


class GraphSerializer(serializers.Serializer):
    source_file = serializers.CharField()